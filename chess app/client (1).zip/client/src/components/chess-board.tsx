import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Game } from "@shared/schema";

interface ChessBoardProps {
  game?: Game;
  onSquareClick: (square: string) => void;
  onMove: (from: string, to: string) => Promise<void>;
  onStartNewGame: () => void;
  onFlipBoard: () => void;
  onPauseTelegram: () => void;
  onCalibrateBoard: () => void;
}

const INITIAL_PIECES: Record<string, string> = {
  a8: '♜', b8: '♞', c8: '♝', d8: '♛', e8: '♚', f8: '♝', g8: '♞', h8: '♜',
  a7: '♟', b7: '♟', c7: '♟', d7: '♟', e7: '♟', f7: '♟', g7: '♟', h7: '♟',
  a2: '♙', b2: '♙', c2: '♙', d2: '♙', e2: '♙', f2: '♙', g2: '♙', h2: '♙',
  a1: '♖', b1: '♘', c1: '♗', d1: '♕', e1: '♔', f1: '♗', g1: '♘', h1: '♖',
};

export default function ChessBoard({
  game,
  onSquareClick,
  onMove,
  onStartNewGame,
  onFlipBoard,
  onPauseTelegram,
  onCalibrateBoard
}: ChessBoardProps) {
  const [selectedSquare, setSelectedSquare] = useState<string | null>(null);
  const [highlightedSquares, setHighlightedSquares] = useState<Set<string>>(new Set());
  const [pieces, setPieces] = useState<Record<string, string>>(INITIAL_PIECES);

  const files = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h'];
  const ranks = ['8', '7', '6', '5', '4', '3', '2', '1'];

  useEffect(() => {
    if (game?.fen) {
      // Parse FEN and update pieces
      const fenParts = game.fen.split(' ');
      const position = fenParts[0];
      const newPieces: Record<string, string> = {};
      
      const fenToPiece: Record<string, string> = {
        'K': '♔', 'Q': '♕', 'R': '♖', 'B': '♗', 'N': '♘', 'P': '♙',
        'k': '♚', 'q': '♛', 'r': '♜', 'b': '♝', 'n': '♞', 'p': '♟'
      };
      
      const rows = position.split('/');
      rows.forEach((row, rankIndex) => {
        let fileIndex = 0;
        for (const char of row) {
          if (char >= '1' && char <= '8') {
            fileIndex += parseInt(char);
          } else if (fenToPiece[char]) {
            const square = files[fileIndex] + ranks[rankIndex];
            newPieces[square] = fenToPiece[char];
            fileIndex++;
          }
        }
      });
      
      setPieces(newPieces);
    }
  }, [game?.fen]);

  const handleSquareClick = async (square: string) => {
    if (selectedSquare) {
      if (selectedSquare === square) {
        // Deselect
        setSelectedSquare(null);
        setHighlightedSquares(new Set());
      } else {
        // Try to make a move
        try {
          await onMove(selectedSquare, square);
          setSelectedSquare(null);
          setHighlightedSquares(new Set());
        } catch (error) {
          console.error("Invalid move:", error);
          setSelectedSquare(square);
        }
      }
    } else {
      // Select square
      setSelectedSquare(square);
      // TODO: Calculate and highlight legal moves
    }
    
    onSquareClick(square);
  };

  const getSquareColor = (file: string, rank: string) => {
    const fileIndex = files.indexOf(file);
    const rankIndex = ranks.indexOf(rank);
    const isLight = (fileIndex + rankIndex) % 2 === 0;
    return isLight ? 'bg-chess-light' : 'bg-chess-dark text-white';
  };

  const getSquareClasses = (square: string) => {
    const [file, rank] = square.split('');
    let classes = `chess-square ${getSquareColor(file, rank)}`;
    
    if (selectedSquare === square) {
      classes += ' selected';
    }
    if (highlightedSquares.has(square)) {
      classes += ' highlighted';
    }
    
    return classes;
  };

  return (
    <Card className="bg-card rounded-lg shadow-lg p-4">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-semibold text-foreground">Game Board</h2>
        <div className="flex items-center space-x-2 text-sm text-muted-foreground">
          <span>Move: <span className="font-mono text-foreground" data-testid="text-move-number">
            {game ? Math.ceil(((game.pgn || "").split(' ').length - 1) / 2) : 1}
          </span></span>
          <span>•</span>
          <span>Turn: <span className="font-semibold text-foreground" data-testid="text-current-player">
            {game?.currentPlayer === 'white' ? 'White' : 'Black'}
          </span></span>
        </div>
      </div>

      {/* Chessboard Container */}
      <div className="relative bg-border p-2 rounded-lg">
        {/* Top Coordinates */}
        <div className="flex mb-1">
          <div className="w-6"></div>
          {files.map(file => (
            <div key={file} className="flex-1 text-center text-xs font-semibold text-muted-foreground">
              {file}
            </div>
          ))}
        </div>

        {/* Chess Board Grid */}
        <div className="grid grid-cols-9 gap-0 bg-chess-dark p-1 rounded">
          {ranks.map(rank => (
            <div key={`rank-${rank}`} className="contents">
              <div className="flex items-center justify-center text-xs font-semibold text-white w-6">
                {rank}
              </div>
              {files.map(file => {
                const square = file + rank;
                return (
                  <div
                    key={square}
                    className={getSquareClasses(square)}
                    data-square={square}
                    data-testid={`square-${square}`}
                    onClick={() => handleSquareClick(square)}
                  >
                    {pieces[square] || ''}
                  </div>
                );
              })}
            </div>
          ))}
        </div>
      </div>

      {/* Game Controls */}
      <div className="flex flex-wrap gap-2 mt-4">
        <Button 
          onClick={onStartNewGame} 
          className="px-4 py-2 bg-primary text-primary-foreground hover:bg-primary/90 font-medium text-sm"
          data-testid="button-start-game"
        >
          <svg className="w-4 h-4 mr-2" fill="currentColor" viewBox="0 0 24 24">
            <path d="M8 5v14l11-7z"/>
          </svg>
          Start Game
        </Button>
        
        <Button 
          onClick={onFlipBoard}
          className="px-4 py-2 bg-secondary text-secondary-foreground hover:bg-secondary/90 font-medium text-sm"
          data-testid="button-flip-board"
        >
          <svg className="w-4 h-4 mr-2" fill="currentColor" viewBox="0 0 24 24">
            <path d="M4 12l1.41 1.41L11 7.83V20h2V7.83l5.58 5.59L20 12l-8-8-8 8z"/>
          </svg>
          Flip Board
        </Button>
        
        <Button 
          onClick={onPauseTelegram}
          variant="outline"
          className="px-4 py-2 font-medium text-sm"
          data-testid="button-pause-telegram"
        >
          <svg className="w-4 h-4 mr-2" fill="currentColor" viewBox="0 0 24 24">
            <path d="M6 19h4V5H6v14zm8-14v14h4V5h-4z"/>
          </svg>
          Pause Telegram
        </Button>
        
        <Button 
          onClick={onCalibrateBoard}
          variant="ghost"
          className="px-4 py-2 font-medium text-sm"
          data-testid="button-calibrate"
        >
          <svg className="w-4 h-4 mr-2" fill="currentColor" viewBox="0 0 24 24">
            <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/>
          </svg>
          Calibrate
        </Button>
      </div>
    </Card>
  );
}
