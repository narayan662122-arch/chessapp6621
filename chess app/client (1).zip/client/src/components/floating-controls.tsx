import { Button } from "@/components/ui/button";

interface FloatingControlsProps {
  onToggleFullscreen: () => void;
  onResetGame: () => void;
  onShowHelp: () => void;
}

export default function FloatingControls({
  onToggleFullscreen,
  onResetGame,
  onShowHelp
}: FloatingControlsProps) {
  return (
    <div className="floating-controls">
      <Button 
        size="icon"
        onClick={onToggleFullscreen}
        className="w-12 h-12 bg-primary text-primary-foreground rounded-full shadow-lg hover:shadow-xl transition-all hover:bg-primary/90"
        data-testid="button-fullscreen"
      >
        <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
          <path d="M7 14H5v5h5v-2H7v-3zm-2-4h2V7h3V5H5v5zm12 7h-3v2h5v-5h-2v3zM14 5v2h3v3h2V5h-5z"/>
        </svg>
      </Button>
      
      <Button 
        size="icon"
        onClick={onResetGame}
        className="w-12 h-12 bg-secondary text-secondary-foreground rounded-full shadow-lg hover:shadow-xl transition-all hover:bg-secondary/90"
        data-testid="button-reset"
      >
        <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
          <path d="M17.65 6.35C16.2 4.9 14.21 4 12 4c-4.42 0-7.99 3.58-7.99 8s3.57 8 7.99 8c3.73 0 6.84-2.55 7.73-6h-2.08c-.82 2.33-3.04 4-5.65 4-3.31 0-6-2.69-6-6s2.69-6 6-6c1.66 0 3.14.69 4.22 1.78L13 11h7V4l-2.35 2.35z"/>
        </svg>
      </Button>
      
      <Button 
        size="icon"
        onClick={onShowHelp}
        variant="outline"
        className="w-12 h-12 rounded-full shadow-lg hover:shadow-xl transition-all"
        data-testid="button-help"
      >
        <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
          <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 17h-2v-2h2v2zm2.07-7.75l-.9.92C13.45 12.9 13 13.5 13 15h-2v-.5c0-1.1.45-2.1 1.17-2.83l1.24-1.26c.37-.36.59-.86.59-1.41 0-1.1-.9-2-2-2s-2 .9-2 2H8c0-2.21 1.79-4 4-4s4 1.79 4 4c0 .88-.36 1.68-.93 2.25z"/>
        </svg>
      </Button>
    </div>
  );
}
