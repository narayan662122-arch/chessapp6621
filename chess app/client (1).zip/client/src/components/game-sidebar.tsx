import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Slider } from "@/components/ui/slider";
import { Game, Move, TelegramQueueItem } from "@shared/schema";

interface GameSidebarProps {
  game?: Game;
  moves: Move[];
  telegramQueue: TelegramQueueItem[];
  isConnected: boolean;
  onUpdateSettings: (settings: Partial<Game>) => void;
  onProcessTelegramQueue: () => void;
}

export default function GameSidebar({
  game,
  moves,
  telegramQueue,
  isConnected,
  onUpdateSettings,
  onProcessTelegramQueue
}: GameSidebarProps) {
  const handleEngineLevel = (value: string) => {
    onUpdateSettings({ engineLevel: value });
  };

  const handleAutoPlay = (checked: boolean) => {
    onUpdateSettings({ autoPlay: checked });
  };

  const getEngineStatus = () => {
    if (!game) return "Idle";
    return game.currentPlayer !== game.playerColor ? "Thinking..." : "Ready";
  };

  const getLastMove = () => {
    if (moves.length === 0) return "None";
    return moves[moves.length - 1].moveNotation;
  };

  const formatMoveHistory = () => {
    const movePairs: { white: string; black?: string; moveNumber: number }[] = [];
    
    for (let i = 0; i < moves.length; i += 2) {
      const whiteMove = moves[i];
      const blackMove = moves[i + 1];
      
      movePairs.push({
        moveNumber: Math.floor(i / 2) + 1,
        white: whiteMove?.moveNotation || "",
        black: blackMove?.moveNotation
      });
    }
    
    return movePairs;
  };

  return (
    <div className="space-y-6">
      {/* Game Status */}
      <Card className="bg-card rounded-lg shadow-lg p-4">
        <h3 className="text-lg font-semibold text-foreground mb-3">Game Status</h3>
        
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-sm text-muted-foreground">Engine Status</span>
            <div className="flex items-center">
              <span className={`status-indicator ${
                getEngineStatus() === "Thinking..." ? "status-thinking" : "status-connected"
              }`}></span>
              <span className="text-sm font-medium" data-testid="text-engine-status">
                {getEngineStatus()}
              </span>
            </div>
          </div>
          
          <div className="flex items-center justify-between">
            <span className="text-sm text-muted-foreground">Telegram Bot</span>
            <div className="flex items-center">
              <span className={`status-indicator ${
                isConnected ? "status-connected" : "status-disconnected"
              }`}></span>
              <span className="text-sm font-medium" data-testid="text-telegram-status">
                {isConnected ? "Connected" : "Disconnected"}
              </span>
            </div>
          </div>

          <div className="flex items-center justify-between">
            <span className="text-sm text-muted-foreground">Player Colors</span>
            <div className="text-sm font-medium">
              <span className="text-foreground" data-testid="text-player-colors">
                Human: {game?.playerColor === 'white' ? 'White' : 'Black'}
              </span>
            </div>
          </div>

          <div className="border-t border-border pt-3">
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Last Move</span>
              <span className="font-mono text-sm text-foreground" data-testid="text-last-move">
                {getLastMove()}
              </span>
            </div>
          </div>
        </div>
      </Card>

      {/* Move History */}
      <Card className="bg-card rounded-lg shadow-lg p-4">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-lg font-semibold text-foreground">Move History</h3>
          <Button variant="ghost" size="sm" data-testid="button-export-pgn">
            Export PGN
          </Button>
        </div>
        
        <div className="move-history">
          <div className="space-y-1">
            {formatMoveHistory().map((movePair, index) => (
              <div key={index} className="flex items-center text-sm" data-testid={`move-pair-${index}`}>
                <span className="w-8 text-muted-foreground font-mono">{movePair.moveNumber}.</span>
                <span className="flex-1 font-mono">{movePair.white}</span>
                <span className="flex-1 font-mono text-muted-foreground">
                  {movePair.black || "..."}
                </span>
              </div>
            ))}
            {moves.length === 0 && (
              <div className="text-sm text-muted-foreground text-center py-4">
                No moves yet
              </div>
            )}
          </div>
        </div>
      </Card>

      {/* Telegram Queue */}
      <Card className="bg-card rounded-lg shadow-lg p-4">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-lg font-semibold text-foreground">Telegram Queue</h3>
          <span className="text-xs bg-primary text-primary-foreground px-2 py-1 rounded-full" 
                data-testid="text-queue-count">
            {telegramQueue.length}
          </span>
        </div>
        
        <div className="space-y-2">
          {telegramQueue.map((queueItem, index) => (
            <div key={queueItem.id} className="flex items-center justify-between p-2 bg-muted rounded-md"
                 data-testid={`queue-item-${index}`}>
              <span className="font-mono text-sm">{queueItem.moveNotation}</span>
              <span className="text-xs text-muted-foreground">
                {queueItem.timestamp?.toLocaleTimeString('en-US', { 
                  hour12: false, 
                  hour: '2-digit', 
                  minute: '2-digit' 
                })}
              </span>
            </div>
          ))}
          {telegramQueue.length === 0 && (
            <div className="text-sm text-muted-foreground text-center py-4">
              No pending moves
            </div>
          )}
        </div>

        <Button 
          onClick={onProcessTelegramQueue}
          className="w-full mt-3 px-4 py-2 bg-primary text-primary-foreground hover:bg-primary/90 font-medium text-sm"
          disabled={telegramQueue.length === 0}
          data-testid="button-execute-moves"
        >
          <svg className="w-4 h-4 mr-2" fill="currentColor" viewBox="0 0 24 24">
            <path d="M8 5v14l11-7z"/>
          </svg>
          Execute Moves ({telegramQueue.length})
        </Button>
      </Card>

      {/* Engine Settings */}
      <Card className="bg-card rounded-lg shadow-lg p-4">
        <h3 className="text-lg font-semibold text-foreground mb-3">Engine Settings</h3>
        
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-foreground mb-2">Difficulty Level</label>
            <Select value={game?.engineLevel || "5"} onValueChange={handleEngineLevel}>
              <SelectTrigger data-testid="select-engine-level">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="1">Beginner (1)</SelectItem>
                <SelectItem value="5">Intermediate (5)</SelectItem>
                <SelectItem value="10">Advanced (10)</SelectItem>
                <SelectItem value="20">Master (20)</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <label className="block text-sm font-medium text-foreground mb-2">Think Time</label>
            <Slider
              defaultValue={[5]}
              max={30}
              min={1}
              step={1}
              className="w-full"
              data-testid="slider-think-time"
            />
            <div className="flex justify-between text-xs text-muted-foreground mt-1">
              <span>1s</span>
              <span data-testid="text-current-think-time">5s</span>
              <span>30s</span>
            </div>
          </div>

          <div className="flex items-center justify-between">
            <span className="text-sm font-medium text-foreground">Auto-play</span>
            <Switch
              checked={game?.autoPlay || false}
              onCheckedChange={handleAutoPlay}
              data-testid="switch-auto-play"
            />
          </div>
        </div>
      </Card>
    </div>
  );
}
