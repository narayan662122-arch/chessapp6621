import { useState, useCallback } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Game, Move, TelegramQueueItem, InsertGame } from "@shared/schema";
import { ChessEngine } from "@/lib/chess-engine";
import { Chess } from "chess.js";

export function useChessGame(gameId?: string) {
  const [chessEngine] = useState(() => new ChessEngine());
  const { toast } = useToast();

  // Fetch game data
  const { data: game, isLoading: gameLoading } = useQuery<Game>({
    queryKey: ['/api/games', gameId],
    enabled: !!gameId,
  });

  // Fetch moves
  const { data: moves = [] } = useQuery<Move[]>({
    queryKey: ['/api/games', gameId, 'moves'],
    enabled: !!gameId,
  });

  // Fetch Telegram queue
  const { data: telegramQueue = [] } = useQuery<TelegramQueueItem[]>({
    queryKey: ['/api/games', gameId, 'telegram-queue'],
    enabled: !!gameId,
  });

  // Create new game mutation
  const createGameMutation = useMutation({
    mutationFn: async (gameData: InsertGame) => {
      const response = await apiRequest('POST', '/api/games', gameData);
      return response.json() as Promise<Game>;
    },
    onSuccess: (newGame) => {
      queryClient.setQueryData(['/api/games', newGame.id], newGame);
      toast({
        title: "Game Created",
        description: "New chess game started successfully"
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to create new game",
        variant: "destructive"
      });
      console.error('Create game error:', error);
    }
  });

  // Update game mutation
  const updateGameMutation = useMutation({
    mutationFn: async ({ gameId, updates }: { gameId: string; updates: Partial<InsertGame> }) => {
      const response = await apiRequest('PATCH', `/api/games/${gameId}`, updates);
      return response.json() as Promise<Game>;
    },
    onSuccess: (updatedGame) => {
      queryClient.setQueryData(['/api/games', updatedGame.id], updatedGame);
      queryClient.invalidateQueries({ queryKey: ['/api/games', updatedGame.id] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to update game",
        variant: "destructive"
      });
      console.error('Update game error:', error);
    }
  });

  // Create move mutation
  const createMoveMutation = useMutation({
    mutationFn: async ({ gameId, moveData }: { gameId: string; moveData: Omit<Move, 'id' | 'gameId' | 'timestamp'> }) => {
      const response = await apiRequest('POST', `/api/games/${gameId}/moves`, moveData);
      return response.json() as Promise<Move>;
    },
    onSuccess: () => {
      if (gameId) {
        queryClient.invalidateQueries({ queryKey: ['/api/games', gameId, 'moves'] });
        queryClient.invalidateQueries({ queryKey: ['/api/games', gameId] });
      }
    },
    onError: (error) => {
      toast({
        title: "Invalid Move",
        description: "The move you attempted is not legal",
        variant: "destructive"
      });
      console.error('Create move error:', error);
    }
  });

  // Process Telegram queue mutation
  const processTelegramMutation = useMutation({
    mutationFn: async (queueId: string) => {
      const response = await apiRequest('POST', `/api/games/${gameId}/telegram-queue/${queueId}/process`);
      return response.json();
    },
    onSuccess: () => {
      if (gameId) {
        queryClient.invalidateQueries({ queryKey: ['/api/games', gameId, 'telegram-queue'] });
      }
      toast({
        title: "Move Processed",
        description: "Telegram move executed successfully"
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to process Telegram move",
        variant: "destructive"
      });
      console.error('Process telegram move error:', error);
    }
  });

  const createGame = useCallback(async (gameData: InsertGame) => {
    return createGameMutation.mutateAsync(gameData);
  }, [createGameMutation]);

  const makeMove = useCallback(async (from: string, to: string) => {
    if (!gameId || !game) return;

    try {
      // Validate move using chess.js
      const chess = new Chess(game.fen);
      const uciNotation = from + to;
      
      // Validate the move
      const move = chess.move(uciNotation);
      if (!move) {
        throw new Error("Invalid move");
      }

      // Create move data with proper notation
      const moveData = {
        moveNotation: move.san,
        uciNotation,
        moveNumber: Math.ceil(chess.moveNumber()).toString(),
        player: game.currentPlayer,
        source: 'manual' as const
      };

      await createMoveMutation.mutateAsync({ gameId, moveData });

      // Update game state with new FEN and PGN
      const newCurrentPlayer = chess.turn() === 'w' ? 'white' : 'black';
      const gameStatus = chess.isGameOver() ? 
        (chess.isCheckmate() ? 'checkmate' : 
         chess.isDraw() ? 'draw' : 'finished') : 'active';

      await updateGameMutation.mutateAsync({
        gameId,
        updates: {
          fen: chess.fen(),
          currentPlayer: newCurrentPlayer,
          pgn: chess.pgn(),
          gameStatus
        }
      });

      // If it's engine's turn and auto-play is enabled, make engine move
      if (game.autoPlay && newCurrentPlayer !== game.playerColor && !chess.isGameOver()) {
        setTimeout(() => makeEngineMove(chess.fen()), 1000);
      }

    } catch (error) {
      throw error;
    }
  }, [gameId, game, moves, chessEngine, createMoveMutation, updateGameMutation]);

  const makeEngineMove = useCallback(async (currentFen: string) => {
    if (!gameId || !game) return;

    try {
      // Set engine difficulty from game settings
      chessEngine.setDifficulty(parseInt(game.engineLevel || '5'));
      
      const engineMoveUci = await chessEngine.getBestMove(currentFen);
      if (engineMoveUci) {
        // Apply the move using chess.js
        const chess = new Chess(currentFen);
        const move = chess.move(engineMoveUci);
        
        if (!move) {
          throw new Error("Engine generated invalid move");
        }

        const moveData = {
          moveNotation: move.san,
          uciNotation: engineMoveUci,
          moveNumber: Math.ceil(chess.moveNumber()).toString(),
          player: game.currentPlayer,
          source: 'engine' as const
        };

        await createMoveMutation.mutateAsync({ gameId, moveData });

        const newCurrentPlayer = chess.turn() === 'w' ? 'white' : 'black';
        const gameStatus = chess.isGameOver() ? 
          (chess.isCheckmate() ? 'checkmate' : 
           chess.isDraw() ? 'draw' : 'finished') : 'active';

        await updateGameMutation.mutateAsync({
          gameId,
          updates: {
            fen: chess.fen(),
            currentPlayer: newCurrentPlayer,
            pgn: chess.pgn(),
            gameStatus
          }
        });

        toast({
          title: "Engine Move",
          description: `Engine played: ${move.san}`,
        });
      }
    } catch (error) {
      console.error('Engine move error:', error);
      toast({
        title: "Engine Error",
        description: "Failed to make engine move",
        variant: "destructive"
      });
    }
  }, [gameId, game, moves, chessEngine, createMoveMutation, updateGameMutation, toast]);

  const flipBoard = useCallback(async () => {
    if (!gameId) return;

    await updateGameMutation.mutateAsync({
      gameId,
      updates: {
        boardFlipped: !game?.boardFlipped
      }
    });
  }, [gameId, game, updateGameMutation]);

  const updateGameSettings = useCallback(async (settings: Partial<Game>) => {
    if (!gameId) return;

    await updateGameMutation.mutateAsync({
      gameId,
      updates: settings
    });
  }, [gameId, updateGameMutation]);

  const processTelegramQueue = useCallback(async () => {
    for (const queueItem of telegramQueue) {
      await processTelegramMutation.mutateAsync(queueItem.id);
    }
  }, [telegramQueue, processTelegramMutation]);

  return {
    game,
    moves,
    telegramQueue,
    isLoading: gameLoading || createGameMutation.isPending,
    createGame,
    makeMove,
    flipBoard,
    updateGameSettings,
    processTelegramQueue
  };
}
