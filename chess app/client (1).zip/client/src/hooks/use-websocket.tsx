import { useState, useEffect, useRef, useCallback } from "react";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";

export function useWebSocket(gameId?: string) {
  const [isConnected, setIsConnected] = useState(false);
  const [socket, setSocket] = useState<WebSocket | null>(null);
  const { toast } = useToast();
  const reconnectTimeoutRef = useRef<NodeJS.Timeout>();
  const reconnectAttempts = useRef(0);

  const connect = useCallback(() => {
    if (!gameId) return;

    try {
      const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
      const wsUrl = `${protocol}//${window.location.host}/ws?gameId=${gameId}`;
      const ws = new WebSocket(wsUrl);

      ws.onopen = () => {
        console.log('WebSocket connected');
        setIsConnected(true);
        setSocket(ws);
        reconnectAttempts.current = 0;
      };

      ws.onclose = () => {
        console.log('WebSocket disconnected');
        setIsConnected(false);
        setSocket(null);
        
        // Attempt to reconnect with exponential backoff
        if (reconnectAttempts.current < 5) {
          const delay = Math.pow(2, reconnectAttempts.current) * 1000;
          reconnectTimeoutRef.current = setTimeout(() => {
            reconnectAttempts.current++;
            connect();
          }, delay);
        }
      };

      ws.onerror = (error) => {
        console.error('WebSocket error:', error);
        toast({
          title: "Connection Error",
          description: "Lost connection to game server",
          variant: "destructive"
        });
      };

      ws.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          handleMessage(data);
        } catch (error) {
          console.error('Error parsing WebSocket message:', error);
        }
      };

    } catch (error) {
      console.error('WebSocket connection error:', error);
      toast({
        title: "Connection Failed",
        description: "Unable to connect to game server",
        variant: "destructive"
      });
    }
  }, [gameId, toast]);

  const handleMessage = (data: any) => {
    switch (data.type) {
      case 'move':
        // Invalidate game and move queries to refresh UI
        if (gameId) {
          queryClient.invalidateQueries({ queryKey: ['/api/games', gameId] });
          queryClient.invalidateQueries({ queryKey: ['/api/games', gameId, 'moves'] });
        }
        break;

      case 'new_move':
        // Refresh move history
        if (gameId) {
          queryClient.invalidateQueries({ queryKey: ['/api/games', gameId, 'moves'] });
        }
        toast({
          title: "New Move",
          description: `Move: ${data.move.moveNotation}`,
        });
        break;

      case 'game_update':
        // Update game data in cache
        if (gameId) {
          queryClient.setQueryData(['/api/games', gameId], data.game);
        }
        break;

      case 'telegram_move_received':
        toast({
          title: "Telegram Move",
          description: `Received move: ${data.move}`,
        });
        // Refresh telegram queue
        if (gameId) {
          queryClient.invalidateQueries({ queryKey: ['/api/games', gameId, 'telegram-queue'] });
        }
        break;

      case 'telegram_queue_update':
        // Update telegram queue in cache
        if (gameId) {
          queryClient.setQueryData(['/api/games', gameId, 'telegram-queue'], data.queue);
        }
        break;

      default:
        console.log('Unknown message type:', data.type);
    }
  };

  const sendMessage = useCallback((message: any) => {
    if (socket && socket.readyState === WebSocket.OPEN) {
      socket.send(JSON.stringify(message));
    } else {
      console.warn('WebSocket not connected, message not sent:', message);
    }
  }, [socket]);

  useEffect(() => {
    connect();

    return () => {
      if (reconnectTimeoutRef.current) {
        clearTimeout(reconnectTimeoutRef.current);
      }
      if (socket) {
        socket.close();
      }
    };
  }, [connect]);

  return {
    isConnected,
    sendMessage
  };
}
