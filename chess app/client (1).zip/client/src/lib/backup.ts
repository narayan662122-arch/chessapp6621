interface GameBackup {
  timestamp: number;
  gameId: string;
  gameState: any;
  moves: any[];
  telegramQueue: any[];
}

const BACKUP_KEY = 'chess_game_backup';
const BACKUP_INTERVAL = 150000; // 2.5 minutes

let backupInterval: NodeJS.Timeout | null = null;

export function startBackupService(): () => void {
  console.log('Starting automatic backup service...');
  
  backupInterval = setInterval(() => {
    performBackup();
  }, BACKUP_INTERVAL);

  // Initial backup
  performBackup();

  // Return stop function
  return () => {
    if (backupInterval) {
      clearInterval(backupInterval);
      backupInterval = null;
      console.log('Backup service stopped');
    }
  };
}

function performBackup(): void {
  try {
    const backup: GameBackup = {
      timestamp: Date.now(),
      gameId: getCurrentGameId(),
      gameState: getCurrentGameState(),
      moves: getCurrentMoves(),
      telegramQueue: getCurrentTelegramQueue()
    };

    localStorage.setItem(BACKUP_KEY, JSON.stringify(backup));
    console.log(`Auto-backup completed at ${new Date().toLocaleTimeString()}`);
    
    // Clean up old backups (keep only last 10)
    cleanupOldBackups();
    
  } catch (error) {
    console.error('Backup failed:', error);
  }
}

function getCurrentGameId(): string {
  // Extract game ID from current URL or state
  const path = window.location.pathname;
  const match = path.match(/\/game\/([^\/]+)/);
  return match ? match[1] : '';
}

function getCurrentGameState(): any {
  // Get current game state from localStorage or session storage
  try {
    const gameStateKey = `chess_game_${getCurrentGameId()}`;
    const stored = localStorage.getItem(gameStateKey);
    return stored ? JSON.parse(stored) : null;
  } catch {
    return null;
  }
}

function getCurrentMoves(): any[] {
  // Get current moves from localStorage
  try {
    const movesKey = `chess_moves_${getCurrentGameId()}`;
    const stored = localStorage.getItem(movesKey);
    return stored ? JSON.parse(stored) : [];
  } catch {
    return [];
  }
}

function getCurrentTelegramQueue(): any[] {
  // Get current Telegram queue from localStorage  
  try {
    const queueKey = `telegram_queue_${getCurrentGameId()}`;
    const stored = localStorage.getItem(queueKey);
    return stored ? JSON.parse(stored) : [];
  } catch {
    return [];
  }
}

function cleanupOldBackups(): void {
  try {
    const keys = Object.keys(localStorage).filter(key => key.startsWith(BACKUP_KEY));
    if (keys.length > 10) {
      // Remove oldest backups
      keys.sort().slice(0, keys.length - 10).forEach(key => {
        localStorage.removeItem(key);
      });
    }
  } catch (error) {
    console.error('Backup cleanup failed:', error);
  }
}

export function restoreFromBackup(backupData?: string): GameBackup | null {
  try {
    const data = backupData || localStorage.getItem(BACKUP_KEY);
    if (data) {
      const backup: GameBackup = JSON.parse(data);
      console.log(`Restored backup from ${new Date(backup.timestamp).toLocaleString()}`);
      return backup;
    }
  } catch (error) {
    console.error('Restore from backup failed:', error);
  }
  return null;
}

export function listAvailableBackups(): GameBackup[] {
  try {
    const keys = Object.keys(localStorage).filter(key => key.startsWith(BACKUP_KEY));
    const backups: GameBackup[] = [];
    
    keys.forEach(key => {
      try {
        const backup = JSON.parse(localStorage.getItem(key) || '');
        backups.push(backup);
      } catch {
        // Skip invalid backups
      }
    });
    
    return backups.sort((a, b) => b.timestamp - a.timestamp);
  } catch {
    return [];
  }
}

export function exportBackup(gameId: string): string | null {
  try {
    const backup: GameBackup = {
      timestamp: Date.now(),
      gameId,
      gameState: getCurrentGameState(),
      moves: getCurrentMoves(),
      telegramQueue: getCurrentTelegramQueue()
    };
    
    return JSON.stringify(backup, null, 2);
  } catch (error) {
    console.error('Export backup failed:', error);
    return null;
  }
}
