import { Chess } from 'chess.js';

interface EngineConfig {
  difficulty: number; // 1-10
  thinkingTime: number; // milliseconds
}

export class ChessEngine {
  private difficulty: number;
  private thinkingTime: number;

  constructor(config: EngineConfig = { difficulty: 5, thinkingTime: 1000 }) {
    this.difficulty = config.difficulty;
    this.thinkingTime = config.thinkingTime;
  }

  async makeMove(game: Chess): Promise<string | null> {
    return new Promise((resolve) => {
      setTimeout(() => {
        const moves = game.moves({ verbose: true });
        if (moves.length === 0) {
          resolve(null);
          return;
        }

        // Enhanced move selection based on difficulty
        let selectedMove;
        
        if (this.difficulty >= 8) {
          // Advanced: Prefer capturing moves and checks
          const captureMoves = moves.filter(move => move.captured);
          const checkMoves = moves.filter(move => {
            const tempGame = new Chess(game.fen());
            tempGame.move(move);
            return tempGame.isCheck();
          });
          
          if (captureMoves.length > 0 && Math.random() < 0.7) {
            selectedMove = captureMoves[Math.floor(Math.random() * captureMoves.length)];
          } else if (checkMoves.length > 0 && Math.random() < 0.5) {
            selectedMove = checkMoves[Math.floor(Math.random() * checkMoves.length)];
          } else {
            selectedMove = moves[Math.floor(Math.random() * moves.length)];
          }
        } else if (this.difficulty >= 5) {
          // Intermediate: Sometimes prefer captures
          const captureMoves = moves.filter(move => move.captured);
          if (captureMoves.length > 0 && Math.random() < 0.4) {
            selectedMove = captureMoves[Math.floor(Math.random() * captureMoves.length)];
          } else {
            selectedMove = moves[Math.floor(Math.random() * moves.length)];
          }
        } else {
          // Beginner: Random moves
          selectedMove = moves[Math.floor(Math.random() * moves.length)];
        }

        resolve(selectedMove.san);
      }, this.thinkingTime);
    });
  }

  // Convert UCI format to SAN format using chess.js
  convertUciToSan(game: Chess, uciMove: string): string | null {
    try {
      const move = game.move(uciMove);
      if (move) {
        game.undo(); // Undo the move to keep game state intact
        return move.san;
      }
      return null;
    } catch {
      return null;
    }
  }

  // Convert SAN format to UCI format
  convertSanToUci(game: Chess, sanMove: string): string | null {
    try {
      const move = game.move(sanMove);
      if (move) {
        game.undo(); // Undo the move to keep game state intact
        return move.from + move.to + (move.promotion || '');
      }
      return null;
    } catch {
      return null;
    }
  }

  // Validate if move is legal
  isValidMove(game: Chess, move: string): boolean {
    try {
      const testMove = game.move(move);
      if (testMove) {
        game.undo();
        return true;
      }
      return false;
    } catch {
      return false;
    }
  }

  // Generate the best UCI move for automation
  async getBestMove(fen: string): Promise<string | null> {
    try {
      const game = new Chess(fen);
      const moves = game.moves({ verbose: true });
      
      if (moves.length === 0) return null;

      // Simulate thinking time
      await new Promise(resolve => setTimeout(resolve, this.thinkingTime));

      // Enhanced move selection based on difficulty
      let selectedMove;
      
      if (this.difficulty >= 8) {
        // Advanced: Prefer capturing moves and checks
        const captureMoves = moves.filter(move => move.captured);
        const checkMoves = moves.filter(move => {
          const tempGame = new Chess(fen);
          tempGame.move(move);
          return tempGame.isCheck();
        });
        
        if (captureMoves.length > 0 && Math.random() < 0.7) {
          selectedMove = captureMoves[Math.floor(Math.random() * captureMoves.length)];
        } else if (checkMoves.length > 0 && Math.random() < 0.5) {
          selectedMove = checkMoves[Math.floor(Math.random() * checkMoves.length)];
        } else {
          selectedMove = moves[Math.floor(Math.random() * moves.length)];
        }
      } else if (this.difficulty >= 5) {
        // Intermediate: Sometimes prefer captures
        const captureMoves = moves.filter(move => move.captured);
        if (captureMoves.length > 0 && Math.random() < 0.4) {
          selectedMove = captureMoves[Math.floor(Math.random() * captureMoves.length)];
        } else {
          selectedMove = moves[Math.floor(Math.random() * moves.length)];
        }
      } else {
        // Beginner: Random moves
        selectedMove = moves[Math.floor(Math.random() * moves.length)];
      }

      // Return UCI notation
      return selectedMove.from + selectedMove.to + (selectedMove.promotion || '');
    } catch (error) {
      console.error('Get best move error:', error);
      return null;
    }
  }

  setDifficulty(difficulty: number) {
    this.difficulty = Math.max(1, Math.min(10, difficulty));
  }

  setThinkingTime(time: number) {
    this.thinkingTime = Math.max(100, time);
  }

  getDifficulty(): number {
    return this.difficulty;
  }

  getThinkingTime(): number {
    return this.thinkingTime;
  }
}