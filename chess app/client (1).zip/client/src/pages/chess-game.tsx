import { useState, useEffect } from "react";
import { useParams } from "wouter";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import ChessBoard from "@/components/chess-board";
import GameSidebar from "@/components/game-sidebar";
import FloatingControls from "@/components/floating-controls";
import { useChessGame } from "@/hooks/use-chess-game";
import { useWebSocket } from "@/hooks/use-websocket";
import { startBackupService } from "@/lib/backup";

export default function ChessGame() {
  const { gameId } = useParams();
  const [currentGameId, setCurrentGameId] = useState<string>(gameId || "");
  const {
    game,
    moves,
    telegramQueue,
    isLoading,
    createGame,
    makeMove,
    flipBoard,
    updateGameSettings,
    processTelegramQueue
  } = useChessGame(currentGameId);

  const { isConnected, sendMessage } = useWebSocket(currentGameId);

  useEffect(() => {
    // Start backup service
    const stopBackup = startBackupService();
    return stopBackup;
  }, []);

  useEffect(() => {
    // Create new game if no gameId provided
    if (!currentGameId) {
      handleStartNewGame();
    }
  }, [currentGameId]);

  const handleStartNewGame = async () => {
    try {
      const newGame = await createGame({
        fen: "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1",
        currentPlayer: "white",
        gameStatus: "active",
        playerColor: "white",
        engineLevel: "5",
        autoPlay: false,
        boardFlipped: false
      });
      setCurrentGameId(newGame.id);
    } catch (error) {
      console.error("Failed to create game:", error);
    }
  };

  const handleSquareClick = (square: string) => {
    // This will be handled by the chess board component
    console.log("Square clicked:", square);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen w-full flex items-center justify-center bg-background">
        <div className="text-center">
          <div className="animate-pulse text-lg font-medium text-muted-foreground">
            Loading chess game...
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-background min-h-screen font-sans">
      {/* Header */}
      <header className="bg-card border-b border-border p-4 shadow-sm">
        <div className="container mx-auto flex items-center justify-between max-w-6xl">
          <div className="flex items-center space-x-3">
            <div className="text-primary text-2xl">
              <svg className="w-8 h-8" fill="currentColor" viewBox="0 0 24 24">
                <path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zM12 7c.55 0 1 .45 1 1s-.45 1-1 1-1-.45-1-1 .45-1 1-1zm-4 8c-.55 0-1-.45-1-1s.45-1 1-1 1 .45 1 1-.45 1-1 1zm8 0c-.55 0-1-.45-1-1s.45-1 1-1 1 .45 1 1-.45 1-1 1z"/>
              </svg>
            </div>
            <h1 className="text-xl font-bold text-foreground">Telegram Chess Engine</h1>
          </div>
          
          <div className="flex items-center space-x-4">
            <div className="flex items-center text-sm">
              <span className={`status-indicator ${isConnected ? 'status-connected' : 'status-disconnected'}`}></span>
              <span className="text-muted-foreground">
                {isConnected ? 'Telegram Connected' : 'Disconnected'}
              </span>
            </div>
            
            <Button variant="ghost" size="sm" data-testid="button-settings">
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z" />
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
              </svg>
            </Button>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-6 max-w-6xl">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <ChessBoard 
              game={game}
              onSquareClick={handleSquareClick}
              onMove={makeMove}
              onStartNewGame={handleStartNewGame}
              onFlipBoard={flipBoard}
              onPauseTelegram={() => {}}
              onCalibrateBoard={() => {}}
            />
          </div>
          
          <div className="lg:col-span-1">
            <GameSidebar
              game={game}
              moves={moves}
              telegramQueue={telegramQueue}
              isConnected={isConnected}
              onUpdateSettings={updateGameSettings}
              onProcessTelegramQueue={processTelegramQueue}
            />
          </div>
        </div>
      </main>

      <FloatingControls 
        onToggleFullscreen={() => {}}
        onResetGame={handleStartNewGame}
        onShowHelp={() => {}}
      />

      {/* Backup Indicator */}
      <div className="fixed bottom-4 left-4 z-50">
        <div className="flex items-center space-x-2 bg-card border border-border rounded-full px-3 py-2 shadow-lg">
          <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
          <span className="text-xs text-muted-foreground">Auto-backup active</span>
        </div>
      </div>
    </div>
  );
}
