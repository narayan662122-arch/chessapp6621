import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { insertGameSchema, insertMoveSchema, insertTelegramQueueSchema } from "@shared/schema";
import { initializeTelegramBot, getTelegramBot } from "./telegram-bot";

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);

  // Initialize Telegram bot service
  const telegramToken = process.env.TELEGRAM_BOT_TOKEN;
  if (telegramToken) {
    const bot = initializeTelegramBot(telegramToken);
    console.log('🤖 Telegram bot service started');
    
    // Set webhook URL for production (uncomment when deployed)
    // const webhookUrl = `${process.env.REPLIT_DOMAIN || 'https://your-domain.com'}/api/telegram/webhook`;
    // bot.setWebhook(webhookUrl);
  } else {
    console.warn('⚠️ TELEGRAM_BOT_TOKEN not found - Telegram integration disabled');
  }

  // WebSocket server for real-time communication
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });

  // Store active connections
  const connections = new Map<string, WebSocket>();

  wss.on('connection', (ws, req) => {
    const gameId = new URL(req.url!, `http://${req.headers.host}`).searchParams.get('gameId');
    
    if (gameId) {
      connections.set(gameId, ws);
      console.log(`WebSocket connected for game: ${gameId}`);
    }

    ws.on('message', async (message) => {
      try {
        const data = JSON.parse(message.toString());
        
        switch (data.type) {
          case 'move':
            // Broadcast move to all clients
            broadcastToGame(gameId!, {
              type: 'move',
              move: data.move,
              source: data.source
            });
            break;
            
          case 'telegram_move':
            // Handle Telegram bot move
            if (gameId) {
              await storage.addToTelegramQueue({
                gameId,
                moveNotation: data.move,
                processed: false
              });
              
              broadcastToGame(gameId, {
                type: 'telegram_queue_update',
                queue: await storage.getTelegramQueue(gameId)
              });
            }
            break;
        }
      } catch (error) {
        console.error('WebSocket message error:', error);
      }
    });

    ws.on('close', () => {
      if (gameId) {
        connections.delete(gameId);
        console.log(`WebSocket disconnected for game: ${gameId}`);
      }
    });
  });

  function broadcastToGame(gameId: string, message: any) {
    const ws = connections.get(gameId);
    if (ws && ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify(message));
    }
  }

  // REST API routes
  app.post("/api/games", async (req, res) => {
    try {
      const gameData = insertGameSchema.parse(req.body);
      const game = await storage.createGame(gameData);
      res.json(game);
    } catch (error) {
      console.error('Create game error:', error);
      res.status(400).json({ error: "Invalid game data" });
    }
  });

  app.get("/api/games/:id", async (req, res) => {
    try {
      const game = await storage.getGame(req.params.id);
      if (!game) {
        return res.status(404).json({ error: "Game not found" });
      }
      res.json(game);
    } catch (error) {
      console.error('Get game error:', error);
      res.status(500).json({ error: "Failed to get game" });
    }
  });

  app.patch("/api/games/:id", async (req, res) => {
    try {
      const updates = insertGameSchema.partial().parse(req.body);
      const game = await storage.updateGame(req.params.id, updates);
      if (!game) {
        return res.status(404).json({ error: "Game not found" });
      }
      
      // Broadcast game update to connected clients
      broadcastToGame(req.params.id, {
        type: 'game_update',
        game
      });
      
      res.json(game);
    } catch (error) {
      console.error('Update game error:', error);
      res.status(400).json({ error: "Invalid update data" });
    }
  });

  app.post("/api/games/:gameId/moves", async (req, res) => {
    try {
      const moveData = insertMoveSchema.parse({
        ...req.body,
        gameId: req.params.gameId
      });
      const move = await storage.createMove(moveData);
      
      // Broadcast move to connected clients
      broadcastToGame(req.params.gameId, {
        type: 'new_move',
        move
      });
      
      res.json(move);
    } catch (error) {
      console.error('Create move error:', error);
      res.status(400).json({ error: "Invalid move data" });
    }
  });

  app.get("/api/games/:gameId/moves", async (req, res) => {
    try {
      const moves = await storage.getMoves(req.params.gameId);
      res.json(moves);
    } catch (error) {
      console.error('Get moves error:', error);
      res.status(500).json({ error: "Failed to get moves" });
    }
  });

  app.get("/api/games/:gameId/telegram-queue", async (req, res) => {
    try {
      const queue = await storage.getTelegramQueue(req.params.gameId);
      res.json(queue);
    } catch (error) {
      console.error('Get telegram queue error:', error);
      res.status(500).json({ error: "Failed to get telegram queue" });
    }
  });

  app.post("/api/games/:gameId/telegram-queue/:queueId/process", async (req, res) => {
    try {
      await storage.markTelegramMoveProcessed(req.params.queueId);
      
      // Broadcast queue update
      const queue = await storage.getTelegramQueue(req.params.gameId);
      broadcastToGame(req.params.gameId, {
        type: 'telegram_queue_update',
        queue
      });
      
      res.json({ success: true });
    } catch (error) {
      console.error('Process telegram move error:', error);
      res.status(500).json({ error: "Failed to process move" });
    }
  });

  // Webhook endpoint for Telegram bot
  app.post("/api/telegram/webhook", async (req, res) => {
    try {
      const bot = getTelegramBot();
      if (!bot) {
        return res.status(503).json({ error: "Telegram bot not initialized" });
      }

      // Verify webhook secret token for security
      const secretToken = req.headers['x-telegram-bot-api-secret-token'];
      if (!secretToken || !bot.verifyWebhookSecret(secretToken as string)) {
        console.warn('⚠️ Unauthorized webhook request');
        return res.status(403).json({ error: "Unauthorized" });
      }

      // Process Telegram update
      await bot.processUpdate(req.body);
      res.json({ success: true });
    } catch (error) {
      console.error('❌ Telegram webhook error:', error);
      res.status(500).json({ error: "Failed to process telegram update" });
    }
  });

  // Endpoint to send moves to Telegram (for engine responses)
  app.post("/api/telegram/send-move", async (req, res) => {
    try {
      const { gameId, move, chatId } = req.body;
      const bot = getTelegramBot();
      
      if (!bot) {
        return res.status(503).json({ error: "Telegram bot not initialized" });
      }

      if (!gameId || !move || !chatId) {
        return res.status(400).json({ error: "Missing required fields" });
      }

      await bot.sendMessage(chatId, `🤖 Engine played: ${move}`);
      res.json({ success: true });
    } catch (error) {
      console.error('Send move error:', error);
      res.status(500).json({ error: "Failed to send move to Telegram" });
    }
  });

  return httpServer;
}
