import { type Game, type InsertGame, type Move, type InsertMove, type TelegramQueueItem, type InsertTelegramQueue } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Game methods
  createGame(game: InsertGame): Promise<Game>;
  getGame(id: string): Promise<Game | undefined>;
  updateGame(id: string, updates: Partial<InsertGame>): Promise<Game | undefined>;
  
  // Move methods
  createMove(move: InsertMove): Promise<Move>;
  getMoves(gameId: string): Promise<Move[]>;
  
  // Telegram queue methods
  addToTelegramQueue(queueItem: InsertTelegramQueue): Promise<TelegramQueueItem>;
  getTelegramQueue(gameId: string): Promise<TelegramQueueItem[]>;
  markTelegramMoveProcessed(id: string): Promise<void>;
}

export class MemStorage implements IStorage {
  private games: Map<string, Game>;
  private moves: Map<string, Move>;
  private telegramQueue: Map<string, TelegramQueueItem>;

  constructor() {
    this.games = new Map();
    this.moves = new Map();
    this.telegramQueue = new Map();
  }

  async createGame(insertGame: InsertGame): Promise<Game> {
    const id = randomUUID();
    const now = new Date();
    const game: Game = { 
      fen: "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1",
      pgn: "",
      currentPlayer: "white",
      gameStatus: "active",
      playerColor: "white",
      engineLevel: "5",
      autoPlay: false,
      boardFlipped: false,
      telegramChatId: null,
      ...insertGame, 
      id,
      createdAt: now,
      updatedAt: now
    };
    this.games.set(id, game);
    return game;
  }

  async getGame(id: string): Promise<Game | undefined> {
    return this.games.get(id);
  }

  async updateGame(id: string, updates: Partial<InsertGame>): Promise<Game | undefined> {
    const game = this.games.get(id);
    if (!game) return undefined;
    
    const updatedGame = { 
      ...game, 
      ...updates, 
      updatedAt: new Date() 
    };
    this.games.set(id, updatedGame);
    return updatedGame;
  }

  async createMove(insertMove: InsertMove): Promise<Move> {
    const id = randomUUID();
    const move: Move = { 
      source: "manual",
      ...insertMove, 
      id,
      timestamp: new Date()
    };
    this.moves.set(id, move);
    return move;
  }

  async getMoves(gameId: string): Promise<Move[]> {
    return Array.from(this.moves.values())
      .filter(move => move.gameId === gameId)
      .sort((a, b) => a.timestamp!.getTime() - b.timestamp!.getTime());
  }

  async addToTelegramQueue(insertQueue: InsertTelegramQueue): Promise<TelegramQueueItem> {
    const id = randomUUID();
    const queueItem: TelegramQueueItem = { 
      processed: false,
      ...insertQueue, 
      id,
      timestamp: new Date()
    };
    this.telegramQueue.set(id, queueItem);
    return queueItem;
  }

  async getTelegramQueue(gameId: string): Promise<TelegramQueueItem[]> {
    return Array.from(this.telegramQueue.values())
      .filter(item => item.gameId === gameId && !item.processed)
      .sort((a, b) => a.timestamp!.getTime() - b.timestamp!.getTime());
  }

  async markTelegramMoveProcessed(id: string): Promise<void> {
    const item = this.telegramQueue.get(id);
    if (item) {
      this.telegramQueue.set(id, { ...item, processed: true });
    }
  }
}

export const storage = new MemStorage();
