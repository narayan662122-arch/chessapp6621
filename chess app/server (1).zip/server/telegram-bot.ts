import { storage } from "./storage";
import { Chess } from "chess.js";

interface TelegramMessage {
  message_id: number;
  chat: {
    id: number;
    type: string;
  };
  text?: string;
  from?: {
    id: number;
    username?: string;
    first_name: string;
  };
}

interface TelegramUpdate {
  update_id: number;
  message?: TelegramMessage;
}

export class TelegramBotService {
  private botToken: string;
  private baseUrl: string;
  private secretToken: string;
  private gameChats: Map<string, number> = new Map(); // gameId -> chatId
  private chatGames: Map<number, string> = new Map(); // chatId -> gameId
  private gameInstances: Map<string, Chess> = new Map(); // gameId -> Chess instance
  private processingMoves: Set<string> = new Set(); // gameId -> prevent concurrent processing

  constructor(botToken: string) {
    this.botToken = botToken;
    this.baseUrl = `https://api.telegram.org/bot${botToken}`;
    this.secretToken = this.generateSecretToken();
  }

  async sendMessage(chatId: number, text: string): Promise<void> {
    try {
      const response = await fetch(`${this.baseUrl}/sendMessage`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          chat_id: chatId,
          text,
          parse_mode: 'HTML'
        })
      });

      if (!response.ok) {
        console.error('Failed to send Telegram message:', response.status);
      }
    } catch (error) {
      console.error('Telegram API error:', error);
    }
  }

  async setWebhook(webhookUrl: string): Promise<boolean> {
    try {
      const response = await fetch(`${this.baseUrl}/setWebhook`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          url: webhookUrl,
          allowed_updates: ['message'],
          secret_token: this.secretToken
        })
      });

      const result = await response.json();
      console.log('🔗 Webhook setup result:', result);
      return result.ok;
    } catch (error) {
      console.error('❌ Failed to set webhook:', error);
      return false;
    }
  }

  verifyWebhookSecret(providedToken: string): boolean {
    return providedToken === this.secretToken;
  }

  private generateSecretToken(): string {
    return Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
  }

  async processUpdate(update: TelegramUpdate): Promise<void> {
    const message = update.message;
    if (!message?.text || !message.chat) return;

    const chatId = message.chat.id;
    const text = message.text.trim();

    console.log(`Telegram message from ${chatId}: ${text}`);

    // Handle commands
    if (text.startsWith('/')) {
      await this.handleCommand(chatId, text);
      return;
    }

    // Handle chess moves in UCI format (e.g., e2e4, g1f3)
    if (this.isValidUCIMove(text)) {
      await this.handleChessMove(chatId, text);
      return;
    }

    // Default response
    await this.sendMessage(chatId, 
      "Send chess moves in UCI format (e.g., e2e4, g1f3) or use:\n" +
      "/start - Start new game\n" +
      "/status - Game status\n" +
      "/help - Show help"
    );
  }

  private async handleCommand(chatId: number, command: string): Promise<void> {
    const [cmd] = command.split(' ');

    switch (cmd) {
      case '/start':
        await this.startNewGame(chatId);
        break;
      case '/status':
        await this.showGameStatus(chatId);
        break;
      case '/help':
        await this.sendMessage(chatId, 
          "🤖 <b>Telegram Chess Bot</b>\n\n" +
          "<b>Commands:</b>\n" +
          "/start - Start new automated game\n" +
          "/status - Show current game status\n" +
          "/help - Show this help\n\n" +
          "<b>How to play:</b>\n" +
          "Send moves in UCI format: e2e4, g1f3, etc.\n" +
          "The engine will respond automatically!\n\n" +
          "<b>Example game:</b>\n" +
          "You: e2e4\n" +
          "Bot: Engine played d7d5\n" +
          "You: d2d4\n" +
          "Bot: Engine played g8f6"
        );
        break;
      default:
        await this.sendMessage(chatId, "Unknown command. Type /help for available commands.");
    }
  }

  private async startNewGame(chatId: number): Promise<void> {
    try {
      // Initialize chess game instance
      const chess = new Chess();
      
      // Create new automated game
      const game = await storage.createGame({
        fen: chess.fen(),
        pgn: "",
        currentPlayer: "white",
        gameStatus: "active", 
        playerColor: "black", // Telegram bot plays as black
        engineLevel: "10",
        autoPlay: true, // Enable auto-play for automation
        boardFlipped: false,
        telegramChatId: chatId.toString()
      });

      // Map chat to game and store chess instance
      this.gameChats.set(game.id, chatId);
      this.chatGames.set(chatId, game.id);
      this.gameInstances.set(game.id, chess);

      await this.sendMessage(chatId, 
        "🎯 <b>New automated chess game started!</b>\n\n" +
        "♟️ You play as <b>Black</b>\n" +
        "🤖 Engine plays as <b>White</b>\n" +
        "⚡ Game is fully automated\n\n" +
        "The engine will make the first move. Send your moves in UCI format (e.g., e7e5, g8f6).\n\n" +
        `Game ID: <code>${game.id}</code>`
      );

      // Trigger engine to make first move (white)
      setTimeout(() => this.triggerEngineMove(game.id), 1000);

    } catch (error) {
      console.error('❌ Failed to start game:', error);
      await this.sendMessage(chatId, "❌ Failed to start new game. Please try again.");
    }
  }

  private async showGameStatus(chatId: number): Promise<void> {
    const gameId = this.chatGames.get(chatId);
    if (!gameId) {
      await this.sendMessage(chatId, "No active game. Use /start to begin a new game.");
      return;
    }

    const game = await storage.getGame(gameId);
    if (!game) {
      await this.sendMessage(chatId, "Game not found. Use /start to begin a new game.");
      return;
    }

    const moves = await storage.getMoves(gameId);
    const moveCount = moves.length;
    const lastMove = moves[moves.length - 1];

    await this.sendMessage(chatId,
      `📊 <b>Game Status</b>\n\n` +
      `🎯 Game ID: <code>${game.id}</code>\n` +
      `⭐ Status: ${game.gameStatus}\n` +
      `👤 Current turn: ${game.currentPlayer}\n` +
      `📈 Moves played: ${moveCount}\n` +
      `🎪 Last move: ${lastMove ? lastMove.moveNotation : 'None'}\n` +
      `🤖 Engine level: ${game.engineLevel}\n` +
      `⚡ Auto-play: ${game.autoPlay ? 'ON' : 'OFF'}`
    );
  }

  private async handleChessMove(chatId: number, uciMove: string): Promise<void> {
    const gameId = this.chatGames.get(chatId);
    if (!gameId) {
      await this.sendMessage(chatId, "No active game. Use /start to begin a new game.");
      return;
    }

    try {
      // Add move to Telegram queue for processing
      await storage.addToTelegramQueue({
        gameId,
        moveNotation: uciMove,
        processed: false
      });

      await this.sendMessage(chatId, `✅ Move received: <code>${uciMove}</code>\nProcessing...`);

      // Trigger automated move processing
      setTimeout(() => this.processAutomatedGame(gameId, chatId), 500);

    } catch (error) {
      console.error('Failed to process move:', error);
      await this.sendMessage(chatId, `❌ Failed to process move: <code>${uciMove}</code>`);
    }
  }

  private async processAutomatedGame(gameId: string, chatId: number): Promise<void> {
    try {
      // Prevent concurrent processing for the same game
      if (this.processingMoves.has(gameId)) return;

      const game = await storage.getGame(gameId);
      if (!game) return;

      // Process Telegram moves one at a time
      const telegramQueue = await storage.getTelegramQueue(gameId);
      const unprocessedMoves = telegramQueue.filter(item => !item.processed);
      
      if (unprocessedMoves.length === 0) return;

      // Process only the first unprocessed move to avoid race conditions
      const queueItem = unprocessedMoves[0];
      
      // Validate and apply the move
      const success = await this.applyTelegramMove(gameId, queueItem.moveNotation, chatId);
      if (success) {
        await storage.markTelegramMoveProcessed(queueItem.id);
        
        // Trigger engine response after a short delay
        setTimeout(() => this.triggerEngineMove(gameId), 2000);
      }
    } catch (error) {
      console.error('❌ Failed to process automated game:', error);
    }
  }

  private async applyTelegramMove(gameId: string, uciMove: string, chatId: number): Promise<boolean> {
    try {
      const game = await storage.getGame(gameId);
      const chess = this.gameInstances.get(gameId);
      
      if (!game || !chess) {
        await this.sendMessage(chatId, "❌ Game not found or invalid state.");
        return false;
      }

      // Validate move using chess.js
      try {
        const move = chess.move(uciMove);
        if (!move) {
          await this.sendMessage(chatId, `❌ Invalid move: <code>${uciMove}</code>\nTry a legal move like e7e5, g8f6, etc.`);
          return false;
        }

        // Create move record with proper notation
        const moveData = {
          gameId,
          moveNotation: move.san, // Standard algebraic notation
          uciNotation: uciMove,
          moveNumber: Math.ceil(chess.moveNumber()).toString(),
          player: game.currentPlayer,
          source: "telegram" as const
        };

        await storage.createMove(moveData);

        // Update game state with proper FEN and PGN
        const newCurrentPlayer = chess.turn() === 'w' ? 'white' : 'black';
        const gameStatus = chess.isGameOver() ? 
          (chess.isCheckmate() ? 'checkmate' : 
           chess.isDraw() ? 'draw' : 'finished') : 'active';

        await storage.updateGame(gameId, {
          fen: chess.fen(),
          currentPlayer: newCurrentPlayer,
          pgn: chess.pgn(),
          gameStatus
        });

        let statusMsg = "";
        if (chess.isCheck()) statusMsg += " ✅ Check!";
        if (chess.isGameOver()) {
          if (chess.isCheckmate()) statusMsg += " 🎯 Checkmate!";
          else if (chess.isDraw()) statusMsg += " 🤝 Draw!";
        }

        await this.sendMessage(chatId, 
          `✅ <b>Move applied!</b>${statusMsg}\n` +
          `📝 Your move: <code>${move.san}</code> (${uciMove})\n` +
          `⏳ Engine is thinking...`
        );

        return true;
      } catch (moveError) {
        await this.sendMessage(chatId, `❌ Invalid move: <code>${uciMove}</code>\nError: ${moveError}`);
        return false;
      }
    } catch (error) {
      console.error('❌ Failed to apply Telegram move:', error);
      await this.sendMessage(chatId, `❌ Failed to process move: <code>${uciMove}</code>`);
      return false;
    }
  }

  private async triggerEngineMove(gameId: string): Promise<void> {
    try {
      // Prevent concurrent processing for the same game
      if (this.processingMoves.has(gameId)) return;
      this.processingMoves.add(gameId);

      const game = await storage.getGame(gameId);
      const chess = this.gameInstances.get(gameId);
      const chatId = this.gameChats.get(gameId);
      
      if (!game || !chess || !chatId) {
        this.processingMoves.delete(gameId);
        return;
      }

      // Check if game is over
      if (chess.isGameOver()) {
        let result = "";
        if (chess.isCheckmate()) {
          result = chess.turn() === 'w' ? "🎉 You won by checkmate!" : "😔 Engine won by checkmate!";
        } else if (chess.isDraw()) {
          result = "🤝 Game ended in a draw!";
        }
        
        await this.sendMessage(chatId, `🏁 <b>Game Over!</b>\n${result}\n\nUse /start to play again.`);
        this.processingMoves.delete(gameId);
        return;
      }

      // Generate legal engine move
      const legalMoves = chess.moves({ verbose: true });
      if (legalMoves.length === 0) {
        this.processingMoves.delete(gameId);
        return;
      }

      // Simple engine: pick random legal move (in production, use Stockfish)
      const selectedMove = legalMoves[Math.floor(Math.random() * legalMoves.length)];
      
      // Apply engine move
      const move = chess.move(selectedMove);
      if (!move) {
        this.processingMoves.delete(gameId);
        return;
      }

      // Create move record
      const moveData = {
        gameId,
        moveNotation: move.san,
        uciNotation: selectedMove.from + selectedMove.to + (selectedMove.promotion || ''),
        moveNumber: Math.ceil(chess.moveNumber()).toString(),
        player: game.currentPlayer,
        source: "engine" as const
      };

      await storage.createMove(moveData);

      // Update game state
      const newCurrentPlayer = chess.turn() === 'w' ? 'white' : 'black';
      const gameStatus = chess.isGameOver() ? 
        (chess.isCheckmate() ? 'checkmate' : 
         chess.isDraw() ? 'draw' : 'finished') : 'active';

      await storage.updateGame(gameId, {
        fen: chess.fen(),
        currentPlayer: newCurrentPlayer,
        pgn: chess.pgn(),
        gameStatus
      });

      let statusMsg = "";
      if (chess.isCheck()) statusMsg += " ✅ Check!";
      if (chess.isGameOver()) {
        if (chess.isCheckmate()) statusMsg += " 🎯 Checkmate!";
        else if (chess.isDraw()) statusMsg += " 🤝 Draw!";
      }

      await this.sendMessage(chatId,
        `🤖 <b>Engine played:</b> <code>${move.san}</code>${statusMsg}\n` +
        (chess.isGameOver() ? "🏁 Game Over!" : "🎯 Your turn! Send your next move.")
      );

      this.processingMoves.delete(gameId);

    } catch (error) {
      console.error('❌ Failed to make engine move:', error);
      this.processingMoves.delete(gameId);
    }
  }

  private isValidUCIMove(text: string): boolean {
    // Basic UCI move validation (e.g., e2e4, a7a8q)
    const uciPattern = /^[a-h][1-8][a-h][1-8][qrbn]?$/;
    return uciPattern.test(text.toLowerCase());
  }

  // Get active games for monitoring
  getActiveGames(): Map<string, number> {
    return new Map(this.gameChats);
  }
}

// Global bot instance
let botInstance: TelegramBotService | null = null;

export function initializeTelegramBot(botToken: string): TelegramBotService {
  if (!botInstance) {
    botInstance = new TelegramBotService(botToken);
    console.log('Telegram bot service initialized');
  }
  return botInstance;
}

export function getTelegramBot(): TelegramBotService | null {
  return botInstance;
}