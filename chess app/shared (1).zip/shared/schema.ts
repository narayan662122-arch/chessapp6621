import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, boolean, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const games = pgTable("games", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  fen: text("fen").notNull().default("rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1"),
  pgn: text("pgn").default(""),
  currentPlayer: varchar("current_player", { length: 5 }).notNull().default("white"),
  gameStatus: varchar("game_status", { length: 20 }).notNull().default("active"),
  playerColor: varchar("player_color", { length: 5 }).notNull().default("white"),
  engineLevel: text("engine_level").default("5"),
  autoPlay: boolean("auto_play").default(false),
  boardFlipped: boolean("board_flipped").default(false),
  telegramChatId: text("telegram_chat_id"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const moves = pgTable("moves", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  gameId: varchar("game_id").references(() => games.id).notNull(),
  moveNotation: text("move_notation").notNull(),
  uciNotation: text("uci_notation").notNull(),
  moveNumber: text("move_number").notNull(),
  player: varchar("player", { length: 5 }).notNull(),
  timestamp: timestamp("timestamp").defaultNow(),
  source: varchar("source", { length: 10 }).notNull().default("manual"), // manual, engine, telegram
});

export const telegramQueue = pgTable("telegram_queue", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  gameId: varchar("game_id").references(() => games.id).notNull(),
  moveNotation: text("move_notation").notNull(),
  processed: boolean("processed").default(false),
  timestamp: timestamp("timestamp").defaultNow(),
});

export const insertGameSchema = createInsertSchema(games).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertMoveSchema = createInsertSchema(moves).omit({
  id: true,
  timestamp: true,
});

export const insertTelegramQueueSchema = createInsertSchema(telegramQueue).omit({
  id: true,
  timestamp: true,
});

export type InsertGame = z.infer<typeof insertGameSchema>;
export type Game = typeof games.$inferSelect;
export type InsertMove = z.infer<typeof insertMoveSchema>;
export type Move = typeof moves.$inferSelect;
export type InsertTelegramQueue = z.infer<typeof insertTelegramQueueSchema>;
export type TelegramQueueItem = typeof telegramQueue.$inferSelect;
